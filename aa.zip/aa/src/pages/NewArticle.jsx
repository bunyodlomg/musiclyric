const NewArticle = () => {
  return (
    <div>NewArticle</div>
  )
}

export default NewArticle