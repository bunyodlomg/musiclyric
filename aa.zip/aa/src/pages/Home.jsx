import { useState } from "react";
const Home = () => {
  const [toggleLyrics, setToggleLyrics] = useState("yourLyrics");
  return (
    <div className="">
      <div className="flex gap-5">
        <h1
          onClick={() => setToggleLyrics("yourLyrics")}
          className="home_lyrics"
        >
          Your Lyrics
        </h1>
        <h1
          onClick={() => setToggleLyrics("globalLyrics")}
          className="home_lyrics"
        >
          Global Lyrics
        </h1>
      </div>
      <hr className="w-full h-1 mx-auto bg-gray-100 border-0 rounded dark:bg-gray-700" />
      {toggleLyrics && toggleLyrics === "yourLyrics" ? (
        <p className="border mt-5">Your Lyrics</p>
      ) : (
        <p className="border mt-5">Global Lyrics</p>
      )}
    </div>
  );
};

export default Home;
