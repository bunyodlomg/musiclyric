import Navbar from "./components/navbar/Navbar";
import './App.css'
const App = () => {
  return (
    <div className="container mx-auto">
      <Navbar />
    </div>
  );
};

export default App;
