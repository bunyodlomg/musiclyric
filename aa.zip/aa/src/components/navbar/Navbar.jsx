import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom";
import { PencilSquareIcon } from "@heroicons/react/24/solid";
import { UserCircleIcon } from "@heroicons/react/24/solid";

import Home from "../../pages/Home";
import NewArticle from "../../pages/NewArticle";
import Profile from "../../pages/Profile";
import Settings from "../../pages/Settings";
import { useState } from "react";
const Navbar = () => {
  const [dShow, setDShow] = useState(false);
  return (
    <div className="py-5 container">
      <BrowserRouter>
        <nav>
          <NavLink NavLink to="/" className="mr-auto">
            <img src="./logo.png" alt="logo" className="w-52" />
          </NavLink>
          <NavLink NavLink to="/" className="flex items-center">
            <PencilSquareIcon className="size-5" />
            Home
          </NavLink>
          <NavLink to="/new-article" className="flex items-center">
            <PencilSquareIcon className="size-5" />
            NewArticle
          </NavLink>
          <div className="relative">
            <UserCircleIcon
              onClick={() => setDShow(!dShow)}
              className="size-8 text-gray-600"
            />
            {dShow && (
              <ul className="border absolute right-0 top-10 rounded-md shadow-md p-1">
                <li>
                  <NavLink onClick={() => setDShow(false)} to="/profile">
                    Profile
                  </NavLink>
                </li>
                <li>
                  <NavLink onClick={() => setDShow(false)} to="/settings">
                    Settings
                  </NavLink>
                </li>
              </ul>
            )}
          </div>
        </nav>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/new-article" element={<NewArticle />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default Navbar;
